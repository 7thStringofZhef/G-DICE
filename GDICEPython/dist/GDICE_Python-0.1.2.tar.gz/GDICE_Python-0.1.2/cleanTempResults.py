from GDICE_Python.Scripts import deleteFinishedTempResults

if __name__=="__main__":
    deleteFinishedTempResults()