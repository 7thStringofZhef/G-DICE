from GDICE_Python.Scripts import replaceResultsWithDummyFiles

if __name__ == "__main__":
    replaceResultsWithDummyFiles()