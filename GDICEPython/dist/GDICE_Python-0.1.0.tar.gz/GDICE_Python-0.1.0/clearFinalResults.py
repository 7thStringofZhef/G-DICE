from GDICEPython.GDICE_Python import replaceResultsWithDummyFiles

if __name__ == "__main__":
    replaceResultsWithDummyFiles()