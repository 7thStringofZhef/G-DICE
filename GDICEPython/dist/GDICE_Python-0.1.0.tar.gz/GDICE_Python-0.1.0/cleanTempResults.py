from GDICEPython.GDICE_Python import deleteFinishedTempResults

if __name__=="__main__":
    deleteFinishedTempResults()